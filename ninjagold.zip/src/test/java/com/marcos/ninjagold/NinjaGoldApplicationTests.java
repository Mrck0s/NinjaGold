package com.marcos.ninjagold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjaGoldApplicationTests {

    @Test
    void contextLoads() {
    }

}
